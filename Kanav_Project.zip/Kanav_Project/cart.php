<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <title>City Bookstore</title>
</head>

<body>
    <?php 
        require("mysqli_connect.php");
		include("head.html");
		if(isset($_POST["add_to_cart"]))
        {
            if(isset($_SESSION["my_cart"]))
            {
                $item_array_id = array_column($_SESSION["my_cart"], "item_id");
                if(!in_array($_GET["id"], $item_array_id))
                {
                    $count = count($_SESSION["my_cart"]);
                    $item_array = array(
                        'item_id'			=>	$_GET["id"],
                        'item_name'			=>	$_POST["hidden_name"],
                        'item_price'		=>	$_POST["hidden_price"],
                        'item_quantity'		=>	$_POST["quantity"]
                    );
                    $_SESSION["my_cart"][$count] = $item_array;
                }
                else
                {
                    echo '<script>alert("Book Already Exists in Cart.")</script>';
                }
            }
            else
            {
				
				
      $item_array = array
	(
                    'item_id'			=>	$_GET["id"],'item_name'			=>	$_POST["hidden_name"], 'item_price'		=>	$_POST["hidden_price"],
                    'item_quantity'		=>	$_POST["quantity"]
                );
				
                $_SESSION["my_cart"][0] = $item_array;
            }
        }

        
    ?>
    <main>  
    <br />
		<div class="container">
        <br />
			<h3>Your exciting Order Details</h3>
			<div class="table-responsive">
				<caption>Books in Cart</caption>
				<table class="table table-bordered table-dark table-striped">
					<tr>
						<th width="50%">Book Name</th>
						<th width="10%">Quantity</th>
						<th width="10%">Cost</th>
						<th width="10%">Total</th>
						
					</tr>
					<?php
					if(!empty($_SESSION["my_cart"]))
					{
						$total = 0;
						foreach($_SESSION["my_cart"] as $keys => $values)
						{
					?>
					<tr>
						<td><?php echo $values["item_name"]; ?></td>
						<td><?php echo $values["item_quantity"]; ?></td>
						<td>$ <?php echo $values["item_price"]; ?></td>
						<td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td>
						
					</tr>
					<?php
							$total = $total + ($values["item_quantity"] * $values["item_price"]);
						}
					?>
					<tr>
						<td colspan="3" align="right">Cart Total</td>
						<td align="right">$ <?php echo number_format($total, 2); ?></td>
						
					</tr>
					<?php
					}
					?>
						
				</table>
			</div><br>
			<button style="border-radius: 12px; background-color:#7579e7"align="center" class="btn btn-primary" onClick="window.location = 'checkout.php'">Checkout</button>
			  
        </div>
	</body>
	
    </main>

    
	

</body>

</html>