create database IF NOT EXISTS books;



CREATE TABLE IF NOT EXISTS BookInventory (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
  );


CREATE TABLE IF NOT EXISTS Customers(
    `customer_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `firstname` VARCHAR(255) NOT NULL,
    `lastname` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL
    
);


CREATE TABLE IF NOT EXISTS order_details(
    `order_details_id` INT(255) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT(255) NOT NULL,
    `quantity` INT(255) NOT NULL,
    `price` FLOAT NOT NULL,
    `order_id` INT(255) NOT NULL
     
);

CREATE TABLE IF NOT EXISTS orders(
    `order_id` INT(255) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT(255) NOT NULL,
    `total` FLOAT NOT NULL
     
) ;