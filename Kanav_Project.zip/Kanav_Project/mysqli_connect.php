<?php # mysqli_connect.php

// This file contains the database access information.
// This file also establishes a connection to MySQL,
// selects the database, and sets the encoding.
session_start();
// Set the database access information as constants:
define('DB_USER', 'nirmohan');
define('DB_PASSWORD', 'Kanav Baghla$');
define('DB_HOST', 'localhost');
define('DB_NAME', 'books');
// Make the connection:
$connect = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) OR die('Could not connect to MySQL: ' . mysqli_connect_error() );

// Set the encoding...
mysqli_set_charset($connect, 'utf8');