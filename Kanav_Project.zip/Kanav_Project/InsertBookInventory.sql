INSERT INTO BookInventory  (`id`, `name`, `image`, `price`) VALUES
(1, 'Harry Potter and the Philosopher Stone', 'h1.jpg', 100.00),
(2, 'Harry Potter and the Cursed Child', 'h2.jpg', 200.00),
(3, 'Harry Potter and the Deathly Hallows', 'h3.jpg', 50.00),
(4, 'Harry Potter and the Goblet of Fire', 'h4.jpg', 500.00),
(5, 'The Magical Worlds of Harry Potter', 'h5.jpg', 300.00);