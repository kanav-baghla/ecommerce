<!DOCTYPE html>
<html>

<head>
	<style>
	
		
		h3 {
  font-size: 5em;
			text-align: center;
			color: darkred;
}
		body{
			background-color: orchid;
		}
		
	
	</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <title>City Bookstore</title>
</head>

<body>
    <?php 
        require("mysqli_connect.php");
        include("head.html");
    ?>
    <main>  
    <br />
		<div class="container">
			
		 <h3 style="color:red; border-bottom: 5px solid #0e918c">NEW ARRIVALS </h3>
            <br /><br />
            <div class="row">
			<?php
				$query = "SELECT * FROM BookInventory";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-2" style="margin-top: 10px;">
				<form method="post" action="cart.php?action=add&id=<?php echo $row["id"]; ?>">
					
					
						
						<img style="height:300px; width:400px; vertical-align:middle;margin:0px 20px" src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br/><br>

						<h4 style ="color:#373a40; text-align:center; margin-left:1em 1em;"><?php echo $row["name"]; ?></h4>

						<h4 style="color:#b83b5e; vertical-align:middle; margin:0px 90px; font-weight:bolder">$ <?php echo $row["price"]; ?></h4>

						<input style="vertical-align:middle;margin:10px 40px;" type="text" name="quantity" value="1" class="form-control" />

						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

						<input style="vertical-align:middle;margin:12px 100px; color:#ff9642; background-color:#fff8cd; font-weight:bold; border-radius: 14px;" type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

					
				</form>
			</div>
			<?php
					}
				}
            ?>
           
			</div>
		</div>
    </main>
   
    
</body>

</html>