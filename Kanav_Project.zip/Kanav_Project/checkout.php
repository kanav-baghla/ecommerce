<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>Checkout Page</title>
</head>

<body>
    <?php
    require('mysqli_connect.php');
    include("head.html");
    
	  $store = $_SESSION["my_cart"][0];
   
	
	
    if ($_SERVER['REQUEST_METHOD'] === 'POST') 
	
	
	{
       $q = "insert into Customers (firstname, lastname, email) VALUES ('".$_POST['firstname']."', '".$_POST['lastname']."', '".$_POST['email']."')";
		
		 $result = mysqli_query($connect,$q);
        $total = 0;
        $total = $total + ($store["item_quantity"] * $store["item_price"]);
		
		
        $order_query = "insert into orders ( customer_id, total) VALUES (".mysqli_insert_id($connect).", $total)";
        $order_result = mysqli_query($connect, $order_query);
		
		
		
        $orderline_query = "insert into order_details (product_id, quantity, price, order_id) VALUES ('".$store['item_id']."', '".$store['item_quantity']."', '".$store['item_price']."', ".mysqli_insert_id($connect).")";
		
		
        $orderline_result = mysqli_query($connect, $orderline_query);    
        header('Location: confirmation.php');
		
        exit();
    }
    
    ?>
    
    <main class="container">

      <div style="border-style: solid;  border-radius: 5px;" class="row">
        <div class="col-md-4 order-md-2 mb-4">
        </div>
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Payment Details</h4>
          <form class="needs-validation" novalidate action="checkout.php" method="post">
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" name="firstname" id="firstName" placeholder="" value="" required>
                <div class="invalid-feedback">
              first name is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" name="lastname" id="lastName" placeholder="" value="" required>
                <div class="invalid-feedback">
                   last name is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Email </label>
              <input type="email" class="form-control" name="email" id="email" required>
              <div class="invalid-feedback">
               enter a valid email address for shipping updates.
              </div>
            </div>

           
            

            

         <h4 class="mb-3">Payment</h4>

            <div class="d-block my-3">
              <div class="custom-control custom-radio">
                <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required>
                <label class="custom-control-label" for="credit">Credit card</label>
              </div>
              
              <div class="custom-control custom-radio">
                <input id="paypal" name="paymentMethod" type="radio" class="custom-control-input" required>
                <label class="custom-control-label" for="E-transfer">E-transfer</label>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="cc-name">Name on card</label>
                <input type="text" class="form-control" id="cc-name" placeholder="" required>
                
                <div class="invalid-feedback">
                  Name on card is required
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="cc-number">Credit card number</label>
                <input type="text" class="form-control" id="cc-number" placeholder="" required>
                <div class="invalid-feedback">
                  Credit card number is required
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-3 mb-3">
                <label for="cc-expiration">Expiration date</label>
                <input type="text" class="form-control" id="cc-expiration" placeholder="" required>
                <div class="invalid-feedback">
                  Expiration date required
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="cc-expiration">CVV</label>
                <input type="text" class="form-control" id="cc-cvv" placeholder="" required>
				  <small class="text-muted">at back of your card</small>
                <div class="invalid-feedback">
                  Security code required
                </div>
              </div>
            </div>
            <hr class="mb-4">
			  
			  
            <button style="border-radius: 12px; background-color:#b2deec" class="btn btn-secondary btn-lg " type="submit">CHECKOUT</button>
          </form>
        </div>
      </div>


   
    
    </main>
</body>

</html>